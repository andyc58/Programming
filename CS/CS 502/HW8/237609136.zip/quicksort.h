#include "kruskal.h"

#ifndef _Q_SORT_H
#define _Q_SORT_H



int lessThan(Edge* e1, Edge* e2);

void printEdges(Edge** e, int size);

int partition(Edge** edges, int start, int stop);

void quickSort(Edge** edges, int size);

void qSort(Edge** edges, int start, int stop);


#endif