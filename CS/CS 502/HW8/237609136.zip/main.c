#include <stdio.h>
#include <stdlib.h>
#include "kruskal.h"
#include "quicksort.h"

int main(void) {

    printf("Enter File Containing Graph:\n");
    char* path = malloc(200 * sizeof(char));
    scanf("%s",path);
    FILE *file = fopen(path, "r");
    
    int numNodes;
    Graph *myGraph;
    
    fscanf(file, "%d", &numNodes);
    myGraph = newGraph(numNodes);
    fseek(file, 1, 0);

    int start, end, weight;
    while (fscanf(file, "%d %d %d", &start, &end, &weight) == 3){
        addEdge(myGraph, start , end, weight);
    }
    
    fclose(file);
    printf("Running Kruskal's Algorithm\n");
    printf("Input File: %s\n", path);
    free(path);
    kruskalMST(myGraph);
    deleteGraph(myGraph);

    return 0;
  }