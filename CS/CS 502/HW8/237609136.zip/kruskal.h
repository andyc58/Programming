
#ifndef _KRUSKAL_H
#define _KRUSKAL_H


typedef struct Edge Edge;
struct Edge {
  int source;
  int dest;
  int weight;
};


typedef struct Graph Graph;
struct Graph {
  int E, V;
  Edge** edges;
  
};

typedef struct Subset Subset;
struct Subset {  
    int p;
    int rank;  
} ;

Graph* newGraph(int V);

void Union(int x, int y, Subset A []);

void link(int x, int y, Subset A []);

void makeSet(int x, Subset A []);

int findSet(int x, Subset A[]);

void addEdge(Graph* graph,int source, int dest, int weight);

void kruskalMST(Graph* graph);

void deleteGraph(Graph* myGraph);

#endif
