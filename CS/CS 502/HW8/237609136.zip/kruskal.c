#include <stdlib.h>
#include "kruskal.h"
#include "quicksort.h"

Graph* newGraph(int V) {
    Graph* myGraph = malloc(sizeof(Graph));
    myGraph->V = V;
    myGraph->E = 0;
    myGraph->edges = NULL; // Initialize to NULL, no edges initially
    return myGraph;
}

void deleteGraph(Graph* myGraph){
    Edge** temp = myGraph->edges;
    while(*temp) {
      free(*temp);
      temp++;
    }

    free(myGraph->edges);
    free(myGraph);
}

void addEdge(Graph* graph, int source, int dest, int weight) {
    // Increment the number of edges
    graph->E++;

    // Reallocate memory for edges
    graph->edges = realloc(graph->edges, graph->E * sizeof(Edge));

    // Check if realloc succeeded
    if (graph->edges == NULL) {
        // Handle realloc failure here
        // For simplicity, you can exit the program
        exit(1);
    }

    // Allocate memory for the new edge
    graph->edges[graph->E - 1] = malloc(sizeof(Edge));

    // Access the last element of the edges array
    Edge* newEdge = graph->edges[graph->E - 1];

    // Assign values to the new edge
    newEdge->source = source;
    newEdge->dest = dest;
    newEdge->weight = weight;
}

void Union(int x, int y, Subset A []){
    link(findSet(x, A), findSet(y, A), A);
}

void link(int x, int y, Subset A []){
    if (A[x].rank < A[y].rank)
        A[x].p = y;
    else if (A[x].rank > A[y].rank)
        A[y].p = x;
    else {
        A[y].p = x;
        A[x].rank++;
    }
}


void makeSet(int x, Subset A []){
    A[x].p = x;
    A[x].rank = 0;
}

int findSet(int x, Subset A[]) {
    if (A[x].p != x)
        A[x].p = findSet(A[x].p, A);
    return A[x].p;
}

void kruskalMST(Graph* graph){
    quickSort(graph->edges, graph->E);

    Edge* mst [graph->V];
    int e = 0, i = 0;

    Subset* subsets = (Subset*) malloc(graph->V * sizeof(Subset));
    for (int v = 0; v < graph->V; ++v) {  
        makeSet(v, subsets);
    } 

    while(e < graph->V - 1 && i < graph->E){
        
        Edge* next = graph->edges[i];
        i++;
        int x = findSet(next->source, subsets);
        int y = findSet(next->dest, subsets);

        if (x != y){
            mst[e] = next;
            e++;
            Union(x, y, subsets);
        } 
    }

    printEdges(mst, e);
    free(subsets);

}