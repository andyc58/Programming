#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "quicksort.h"
#include "kruskal.h"

int lessThan(Edge* e1, Edge* e2){

    if (e1->weight < e2->weight){
        return 1;
    }

    if (e1->weight == e2->weight && e1->source < e2->source){
        return 1; 
    }

    if (e1->weight == e2->weight && e1->source == e2->source && e1->dest < e2->dest){
        return 1; 
    }

    return 0;
  
}


void printEdges(Edge** edges, int size){
    int cost = 0;
    for(int i=0; i < size; i++){
        
        if (edges[i]->source < edges[i]->dest)
            printf("Added Edge: (%d, %d) with weight %d\n", edges[i]->source, edges[i]->dest, edges[i]->weight);
        else
            printf("Added Edge: (%d, %d) with weight %d\n", edges[i]->dest, edges[i]->source, edges[i]->weight);
        
        cost += edges[i]->weight;
    }

    printf("MST Weight: %d\n", cost);
}

void quickSort(Edge** edges, int size){
    qSort(edges, 0, size - 1);
}

void qSort(Edge** edges, int start, int stop){
    if(start >= stop){
      return;
    }

    int p = partition(edges,start,stop);
    qSort(edges,start,p-1);
    qSort(edges,p+1,stop);
}
int partition(Edge** edges, int start, int stop){
    int r = start + rand() % (stop - start + 1);
    Edge* temp = edges[r];
    edges[r] = edges[stop];
    edges[stop] = temp;
    

    Edge* pivot = edges[stop];
    int j = start;
    for(int i=start; i < stop; i++){
        if(lessThan(edges[i], pivot)){
            temp = edges[j];
            edges[j] = edges[i];
            edges[i] = temp;
            j++;
            
        }
    }

    edges[stop] = edges[j];
    edges[j] = pivot;

    
    return j;
}