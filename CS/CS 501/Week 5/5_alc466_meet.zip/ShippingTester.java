/**
  ShippingTester.java
  @author Andy Cherney
  @version 1.0.0

*/


public class ShippingTester {
    public static void main(String[] args) {
        
        Van van = new Van(979,86544);
        Van van2 = new Van(856,34436);
        Van van3 = new Van(453,453493);
   
        Pallet pallet1 = new Pallet(1,2,1, "New York, NY", "Ottawa, Canada");
        System.out.println(pallet1.toString()+"\n");

        Pallet pallet2 = new Pallet(20,50,60, "Brussels, Belgium","Paris, France");
        System.out.println(pallet2.toString()+"\n");

        System.out.println("Incorrect dimensions and destinations specified");
        pallet2.setWidth(25);
        pallet2.setHeight(60);
        pallet2.setDepth(75);
        pallet2.setOrigin("Holland, Netherlands");
        pallet2.setDestination("Paris, France");
        System.out.println("Fixed info");
        System.out.println(pallet2.toString()+"\n");
        
        Pallet pallet3 = new Pallet(234,604,104, "Sapporo, Japan","Tokyo, Japan");
        System.out.println(pallet3.toString()+"\n");

        Pallet pallet4 = new Pallet(13,76,53, "Los Angeles, California","Seattle, Washington");
        System.out.println(pallet4.toString()+"\n");

        System.out.println("Comparing Pallets");
        System.out.printf("Palette 1 to Palette 1: %d\n",pallet1.compareTo(pallet1));
        System.out.printf("Palette 1 to Palette 2: %d\n",pallet1.compareTo(pallet2));
        System.out.printf("Palette 2 to Palette 1: %d\n",pallet2.compareTo(pallet1));
        System.out.printf("Palette 4 to Palette 3: %d\n",pallet4.compareTo(pallet3));
        System.out.printf("Palette 2 to Palette 3: %d\n\n",pallet2.compareTo(pallet3));


        System.out.println("Seeing if pallets fit");
        System.out.println(van.load(pallet1));
        System.out.println(van2.load(pallet2));
        System.out.println(van3.load(pallet3));
        System.out.println(van3.load(pallet4));
        System.out.println("\nAfter Unloading");
        System.out.println(van3.unload(pallet4));

    }
}
